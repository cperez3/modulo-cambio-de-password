
<div align="center">
<h2>Curso de introducción a la programación WEB </h2>
<img src="assets/img/umg.png"> 
<h3>Ing. José Vinicio Peña </h3>
<h2>
</div>
