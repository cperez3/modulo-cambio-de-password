<div class="container">
  <ul class="nav">
    
  <li class="nav-item">
      <a class="btn btn-primary" href="/mvcphp-main">Inicio</a>
    </li>
    
    <li class="nav-item">
      <a class="btn btn-primary" href="?controller=alumno&action=register">Registrar</a>
    </li>
    <li class="nav-item">
      <a class="btn btn-danger" href="?controller=alumno&&action=show">Ver registros</a>
    </li>
  </ul>
</div>