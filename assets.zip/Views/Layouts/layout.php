<!DOCTYPE html>
<html lang="es">
<head>
	<title>Crud PHP</title>
	<meta charset="utf-8">

	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
	<script src="https://npmcdn.com/tether@1.2.4/dist/js/tether.min.js"></script>
	<script type="text/javascript" src="assets/js/jquery-3.2.1.min.js"></script>

	<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
	
</head>
<body>
	<header>
		<?php 
			require_once('cabecera.php');
		 ?>
		
	</header>
	<section>
		<?php require_once('routing.php'); ?>
	</section>


	<section>
		<?php require_once('pie.php'); ?>
	</section>

</body>
</html>